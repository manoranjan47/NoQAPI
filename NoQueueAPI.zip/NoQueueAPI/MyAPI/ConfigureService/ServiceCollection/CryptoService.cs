﻿namespace MyAPI.ConfigureService.ServiceCollection
{
    public class CryptoService
    {
    }
}
