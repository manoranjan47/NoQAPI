﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLibrary.DTO
{
    public class DistrictMasterDTO
    {

        public int? StateId { get; set; }

        public string DistrictName { get; set; } = null!;


    }
}
