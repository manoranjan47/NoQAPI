﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLibrary.DTO
{
    public class CountryMasterDTO
    {
       // public int? CountryId { get; set; }

        public string CountryName { get; set; } = null!;

        public string CountryCode { get; set; } = null!;

    }
}
