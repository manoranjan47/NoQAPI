﻿

namespace DataAccessLibrary.Models
{
    public class PaymentTypeMaster
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public bool IsActive { get; set; }

    }
}
